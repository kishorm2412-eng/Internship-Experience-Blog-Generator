document.getElementById("imageForm").onsubmit = function(e) {
  e.preventDefault();
  const photoInput = document.getElementById("photo");
  if (photoInput.files && photoInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function(evt) {
      let images = getImages();
      images.push(evt.target.result);
      saveImages(images);
      showImages();
    }
    reader.readAsDataURL(photoInput.files[0]);
  }
  this.reset();
};

function showImages() {
  let images = getImages();
  const div = document.getElementById("imagesPreview");
  div.innerHTML = images.map(src => `<img src="${src}" style="max-width:120px;max-height:120px;margin:6px;"/>`).join("");
}
showImages();