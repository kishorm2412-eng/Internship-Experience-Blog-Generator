// Store/retrieve feedback in localStorage
function getFeedbacks() {
  return JSON.parse(localStorage.getItem('mentor_feedbacks') || '[]');
}
function saveFeedbacks(feedbacks) {
  localStorage.setItem('mentor_feedbacks', JSON.stringify(feedbacks));
}

document.getElementById('feedbackForm').onsubmit = function(e) {
  e.preventDefault();
  const mentorName = document.getElementById('mentorName').value;
  const feedbackDate = document.getElementById('feedbackDate').value;
  const mentorFeedback = document.getElementById('mentorFeedback').value;
  const includeInReport = document.getElementById('includeInReport').checked;
  let feedbacks = getFeedbacks();
  feedbacks.push({ mentorName, feedbackDate, mentorFeedback, includeInReport });
  saveFeedbacks(feedbacks);
  document.getElementById('feedbackMsg').textContent = "Feedback saved!";
  setTimeout(() => document.getElementById('feedbackMsg').textContent = "", 2000);
  this.reset();
  showFeedbacks();
};

function showFeedbacks() {
  const feedbacks = getFeedbacks();
  const div = document.getElementById('feedbackList');
  if (feedbacks.length === 0) {
    div.innerHTML = "<p>No mentor feedback recorded yet.</p>";
    return;
  }
  div.innerHTML = "<h3>Saved Mentor Feedback</h3>" + feedbacks.map(fb =>
    `<div class="blog-entry">
      <strong>${fb.mentorName}</strong> (${fb.feedbackDate})<br/>
      <em>${fb.mentorFeedback}</em><br/>
      <span>${fb.includeInReport ? "Included in report" : "Not included in report"}</span>
    </div>`
  ).join('');
}
showFeedbacks();