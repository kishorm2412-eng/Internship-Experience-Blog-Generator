<?php
session_start();
$companyMsg = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $companyName = $_POST["companyName"] ?? "";
    $companyLocation = $_POST["companyLocation"] ?? "";
    $companyWebsite = $_POST["companyWebsite"] ?? "";
    $companyMentor = $_POST["companyMentor"] ?? "";
    $internRole = $_POST["internRole"] ?? "";
    $internPeriod = $_POST["internPeriod"] ?? "";

    // Simple validation for required fields
    if ($companyName && $companyLocation && $internRole && $internPeriod) {
        // Example: store in session for demonstration
        $_SESSION['company_details'] = [
            'companyName' => $companyName,
            'companyLocation' => $companyLocation,
            'companyWebsite' => $companyWebsite,
            'companyMentor' => $companyMentor,
            'internRole' => $internRole,
            'internPeriod' => $internPeriod
        ];
        $companyMsg = "Company details saved successfully!";
    } else {
        $companyMsg = "Please fill in all required fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Internship Company Details</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="index.php">Login</a>
    <a href="company.php" class="active">Company Details</a>
    <a href="reflection.php">Log Reflection</a>
    <a href="feedback.php">Mentor Feedback</a>
    <a href="upload.php">Upload Images</a>
    <a href="ai.php">AI Writing</a>
    <a href="style.php">Blog Style</a>
  </nav>
  <main>
    <h2>Enter Internship Company Details</h2>
    <form id="companyForm" method="post" action="">
      <label for="companyName">Company Name:</label>
      <input type="text" id="companyName" name="companyName" required />

      <label for="companyLocation">Location:</label>
      <input type="text" id="companyLocation" name="companyLocation" required />

      <label for="companyWebsite">Website:</label>
      <input type="url" id="companyWebsite" name="companyWebsite" />

      <label for="companyMentor">Mentor/Supervisor Name:</label>
      <input type="text" id="companyMentor" name="companyMentor" />

      <label for="internRole">Your Internship Role/Position:</label>
      <input type="text" id="internRole" name="internRole" required />

      <label for="internPeriod">Internship Period (e.g. June-Aug 2025):</label>
      <input type="text" id="internPeriod" name="internPeriod" required />

      <button type="submit">Save Details</button>
    </form>
    <div id="companyMsg"><?php echo htmlspecialchars($companyMsg); ?></div>
    <?php
    if (!empty($_SESSION['company_details'])) {
      echo "<h3>Saved Company Details:</h3><ul>";
      foreach ($_SESSION['company_details'] as $key => $value) {
        echo "<li><strong>" . htmlspecialchars(ucwords(str_replace("_", " ", $key))) . ":</strong> " . htmlspecialchars($value) . "</li>";
      }
      echo "</ul>";
    }
    ?>
  </main>
</body>
</html>