function getEntries() {
  return JSON.parse(localStorage.getItem("blog_entries") || "[]");
}
function saveEntries(entries) {
  localStorage.setItem("blog_entries", JSON.stringify(entries));
}
function getImages() {
  return JSON.parse(localStorage.getItem("blog_images") || "[]");
}
function saveImages(images) {
  localStorage.setItem("blog_images", JSON.stringify(images));
}
function getStyle() {
  return localStorage.getItem("blog_style") || "story";
}
function setStyle(style) {
  localStorage.setItem("blog_style", style);
}
function getPublic() {
  return localStorage.getItem("blog_public") !== "private";
}
function setPublic(isPublic) {
  localStorage.setItem("blog_public", isPublic ? "public" : "private");
}
function getCompany() {
  return JSON.parse(localStorage.getItem("intern_company") || "{}");
}
function getUser() {
  return localStorage.getItem("blog_user") || "";
}