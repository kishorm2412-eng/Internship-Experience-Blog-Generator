const entries = [];
const blogPreview = document.getElementById("blogPreview");
const form = document.getElementById("reflectionForm");
const shareBtn = document.getElementById("sharePortfolio");
const portfolioUrl = document.getElementById("portfolioUrl");
const copiedMsg = document.getElementById("copiedMsg");

form.addEventListener("submit", function(e) {
  e.preventDefault();
  const week = document.getElementById("week").value;
  const reflection = document.getElementById("reflection").value;
  const feedback = document.getElementById("feedback").value;
  const photoInput = document.getElementById("photo");
  let photoUrl = "";

  if(photoInput.files && photoInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function(evt) {
      photoUrl = evt.target.result;
      addEntry(week, reflection, feedback, photoUrl);
    }
    reader.readAsDataURL(photoInput.files[0]);
  } else {
    addEntry(week, reflection, feedback, "");
  }
});

function addEntry(week, reflection, feedback, photoUrl) {
  entries.push({week, reflection, feedback, photoUrl});
  renderBlog();
  form.reset();
}

function renderBlog() {
  const style = document.getElementById("blogStyle").value;
  blogPreview.innerHTML = entries.map(entry => {
    let html = `<div class="blog-entry"><strong>Week ${entry.week}</strong><br/>`;
    if(entry.photoUrl) html += `<img src="${entry.photoUrl}" alt="Week Photo"/><br/>`;
    if(style === "story") {
      html += `<p>${entry.reflection}</p>`;
      if(entry.feedback) html += `<p><em>Feedback: ${entry.feedback}</em></p>`;
    } else {
      html += `<ul><li>Reflection: ${entry.reflection}</li>`;
      if(entry.feedback) html += `<li>Feedback: ${entry.feedback}</li></ul>`;
    }
    html += `</div>`;
    return html;
  }).join("");
}

// AI Write Reflection/Feedback (mocked)
document.getElementById("aiReflection").onclick = function() {
  document.getElementById("reflection").value = "This week, I learned new skills and faced challenges that helped my professional growth.";
};
document.getElementById("aiFeedback").onclick = function() {
  document.getElementById("feedback").value = "My mentor provided valuable guidance, and I appreciate the collaborative environment.";
};

// PDF Generation
document.getElementById("generatePDF").onclick = function() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.setFontSize(24);
  doc.text("Internship Blog", 20, 20);
  let y = 35;
  entries.forEach((entry, i) => {
    doc.setFontSize(14);
    doc.text(`Week ${entry.week}`, 20, y);
    y += 8;
    if(entry.reflection) {
      doc.setFontSize(12);
      doc.text("Reflection: " + entry.reflection, 22, y);
      y += 7;
    }
    if(entry.feedback) {
      doc.text("Feedback: " + entry.feedback, 22, y);
      y += 7;
    }
    y += 4;
    // Images in PDF (simple, one per entry, base64)
    if(entry.photoUrl) {
      doc.addImage(entry.photoUrl, "JPEG", 22, y, 40, 40);
      y += 44;
    }
    y += 6;
    if (y > 260 && i !== entries.length - 1) { doc.addPage(); y = 20; }
  });
  doc.save("InternshipBlog.pdf");
};

// Share Portfolio (mocked)
shareBtn.onclick = function() {
  portfolioUrl.select();
  document.execCommand("copy");
  copiedMsg.textContent = "Copied!";
  setTimeout(() => copiedMsg.textContent = "", 1800);
};

// Privacy selection (for demo, just disables/enables preview)
document.getElementById("blogPublic").onchange = function() {
  blogPreview.style.opacity = this.value === "private" ? "0.3" : "1";
};

// Initial render
renderBlog();