<?php
session_start();
$reflectionMsg = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $week = $_POST["week"] ?? "";
    $date = $_POST["date"] ?? "";
    $reflection = $_POST["reflection"] ?? "";
    $achievements = $_POST["achievements"] ?? "";
    $learning = $_POST["learning"] ?? "";

    // Simple validation
    if ($week && $date && $reflection && $achievements && $learning) {
        // Build the entry
        $entry = [
            "week" => (int)$week,
            "date" => $date,
            "reflection" => $reflection,
            "achievements" => $achievements,
            "learning" => $learning,
            "feedback" => "",
            "mentor_feedback" => ""
        ];
        // Initialize if not set
        if (!isset($_SESSION['reflections31'])) {
            $_SESSION['reflections31'] = [];
        }
        // Add entry to session array
        $_SESSION['reflections31'][] = $entry;

        $reflectionMsg = "Reflection for Week $week added successfully!";
    } else {
        $reflectionMsg = "All fields are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Log Weekly Reflection</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="index.php">Login</a>
    <a href="company.php">Company Details</a>
    <a href="reflection.php" class="active">Log Reflection</a>
    <a href="feedback.php">Mentor Feedback</a>
    <a href="upload.php">Upload Images</a>
    <a href="ai.php">AI Writing</a>
    <a href="style.php">Blog Style</a>
  </nav>
  <main>
    <h2>Log Weekly Reflection</h2>
    <form id="reflectionForm" method="post" action="">
      <label for="week">Week Number:</label>
      <input type="number" id="week" name="week" min="1" required />

      <label for="date">Date:</label>
      <input type="date" id="date" name="date" required />

      <label for="reflection">Reflection:</label>
      <textarea id="reflection" name="reflection" required placeholder="Describe your experiences and thoughts for the week"></textarea>

      <label for="achievements">Achievements:</label>
      <textarea id="achievements" name="achievements" required placeholder="List your achievements this week"></textarea>

      <label for="learning">Learning Outcomes:</label>
      <textarea id="learning" name="learning" required placeholder="Summarize what you learned"></textarea>

      <button type="submit">Add Entry</button>
    </form>
    <div id="reflectionMsg"><?php echo htmlspecialchars($reflectionMsg); ?></div>

    <!-- Optionally display a table of all reflections so far -->
    <?php if (!empty($_SESSION['reflections31'])): ?>
      <h3>Your Saved Reflections</h3>
      <table border="1" cellpadding="5" style="width:100%;max-width:900px;">
        <tr>
          <th>Week</th>
          <th>Date</th>
          <th>Reflection</th>
          <th>Achievements</th>
          <th>Learning</th>
        </tr>
        <?php foreach ($_SESSION['reflections31'] as $entry): ?>
          <tr>
            <td><?=htmlspecialchars($entry['week'])?></td>
            <td><?=htmlspecialchars($entry['date'])?></td>
            <td><?=htmlspecialchars($entry['reflection'])?></td>
            <td><?=htmlspecialchars($entry['achievements'])?></td>
            <td><?=htmlspecialchars($entry['learning'])?></td>
          </tr>
        <?php endforeach; ?>
      </table>
    <?php endif; ?>
  </main>
</body>
</html>