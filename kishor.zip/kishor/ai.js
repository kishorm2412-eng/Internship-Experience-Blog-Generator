document.getElementById("aiReflection").onclick = function() {
  const week = document.getElementById("aiWeek").value;
  document.getElementById("aiReflectionText").value = `Week ${week}: I learned new skills and overcame challenges that contributed to my growth.`;
};
document.getElementById("aiFeedback").onclick = function() {
  const week = document.getElementById("aiWeek").value;
  document.getElementById("aiFeedbackText").value = `Week ${week}: My mentor provided insightful feedback and I appreciated the team support.`;
};