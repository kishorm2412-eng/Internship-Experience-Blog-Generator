<?php
session_start();
$reflectionSuggestion = "";
$feedbackSuggestion = "";
$aiWeek = isset($_POST['aiWeek']) ? intval($_POST['aiWeek']) : 1;

// Dummy AI suggestion logic, replace with real AI integration or logic
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['aiReflection'])) {
        // You can generate suggestion based on week, user's previous data, etc.
        $reflectionSuggestion = "This week (Week $aiWeek), I improved my skills by working on new tasks and collaborating with the team.";
    }
    if (isset($_POST['aiFeedback'])) {
        $feedbackSuggestion = "Mentor's feedback for Week $aiWeek highlighted my progress and suggested areas for further improvement.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>AI Writing Support</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="index.php">Login</a>
    <a href="company.php">Company Details</a>
    <a href="reflection.php">Log Reflection</a>
    <a href="feedback.php">Mentor Feedback</a>
    <a href="upload.php">Upload Images</a>
    <a href="ai.php" class="active">AI Writing</a>
    <a href="style.php">Blog Style</a>
  </nav>
  <main>
    <h2>AI Writing Support</h2>
    <form method="post" action="">
      <label>Which week?</label>
      <input type="number" name="aiWeek" min="1" value="<?php echo htmlspecialchars($aiWeek); ?>" />
      <div>
        <button type="submit" name="aiReflection">AI Write Reflection</button>
        <button type="submit" name="aiFeedback">AI Write Feedback</button>
      </div>
      <div>
        <label>Reflection Suggestion:</label>
        <textarea name="aiReflectionText" id="aiReflectionText"><?php echo htmlspecialchars($reflectionSuggestion); ?></textarea>
      </div>
      <div>
        <label>Feedback Suggestion:</label>
        <textarea name="aiFeedbackText" id="aiFeedbackText"><?php echo htmlspecialchars($feedbackSuggestion); ?></textarea>
      </div>
    </form>
  </main>
</body>
</html>