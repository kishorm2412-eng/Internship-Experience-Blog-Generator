<?php
session_start();

// Handle POST (update session)
$styleMsg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['blogStyle'])) {
        $_SESSION['blogStyle'] = $_POST['blogStyle'];
        $styleMsg = "Blog style updated!";
    }
    if (isset($_POST['blogPublic'])) {
        $_SESSION['blogPublic'] = $_POST['blogPublic'];
        $styleMsg = "Blog visibility updated!";
    }
}

// Set defaults if not already set
if (!isset($_SESSION['blogStyle'])) $_SESSION['blogStyle'] = "story";
if (!isset($_SESSION['blogPublic'])) $_SESSION['blogPublic'] = "public";
$blogStyle = $_SESSION['blogStyle'];
$blogPublic = $_SESSION['blogPublic'];

// Dummy data for preview (replace with actual session/database logic)
function getCompany() {
    return $_SESSION['company_details'] ?? [
        "companyName" => "",
        "companyLocation" => "",
        "companyWebsite" => "",
        "companyMentor" => "",
        "internRole" => "",
        "internPeriod" => "June-Aug 2025"
    ];
}
function getUser() {
    return $_SESSION["blog_user"] ?? "Your Name";
}
function getEntries() {
    if (isset($_SESSION["reflections31"]) && is_array($_SESSION["reflections31"])) {
        // Group flat reflections by week
        $grouped = [];
        foreach ($_SESSION["reflections31"] as $entry) {
            $week = isset($entry['week']) ? $entry['week'] : 1;
            if (!isset($grouped[$week])) $grouped[$week] = [];
            $grouped[$week][] = $entry;
        }
        $weeks = [];
        foreach ($grouped as $weekNum => $days) {
            $weeks[] = [
                "week" => $weekNum,
                "days" => $days
            ];
        }
        return $weeks;
    }

    // Otherwise, generate dummy data if nothing in session
    $startDate = "2025-06-01";
    $totalDays = 31;
    $weeks = [];
    $dayCounter = 0;
    for ($week = 1; $week <= 4; $week++) {
        $daysInThisWeek = ($week < 4) ? 7 : ($totalDays - $dayCounter);
        $weekData = [];
        for ($d = 1; $d <= $daysInThisWeek; $d++) {
            $date = date('Y-m-d', strtotime("$startDate +$dayCounter days"));
            $weekData[] = [
                "day" => $dayCounter + 1,
                "date" => $date,
                "reflection" => "",
                "achievements" => "",
                "learning" => "",
            ];
            $dayCounter++;
        }
        $weeks[] = [
            "week" => $week,
            "days" => $weekData
        ];
    }
    return $weeks;
}
function getImages() {
    return $_SESSION["uploaded_images"] ?? [];
}
function getMentorFeedbacks() {
    return array_filter($_SESSION['feedbacks'] ?? [], function($fb) {
        return isset($fb['includeInReport']) && $fb['includeInReport'] === "Yes";
    });
}

$portfolioUrl = "https://portfolio.example.com/your-id";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Blog Style, Generate & Share Portfolio</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="index.php">Login</a>
    <a href="company.php">Company Details</a>
    <a href="reflection.php">Log Reflection</a>
    <a href="feedback.php">Mentor Feedback</a>
    <a href="upload.php">Upload Images</a>
    <a href="ai.php">AI Writing</a>
    <a href="style.php" class="active">Blog Style</a>
  </nav>
  <main>
    <h2>Choose Blog Style & Privacy</h2>
    <form method="post" style="margin-bottom:25px;">
      <label>Blog Style:</label>
      <select name="blogStyle" onchange="this.form.submit()">
        <option value="story" <?php if($blogStyle=="story")echo "selected";?>>Story</option>
        <option value="pointwise" <?php if($blogStyle=="pointwise")echo "selected";?>>Pointwise</option>
      </select>
      <label>Visibility:</label>
      <select name="blogPublic" onchange="this.form.submit()">
        <option value="public" <?php if($blogPublic=="public")echo "selected";?>>Public</option>
        <option value="private" <?php if($blogPublic=="private")echo "selected";?>>Private</option>
      </select>
      <span id="styleMsg" style="margin-left:10px;"><?php echo htmlspecialchars($styleMsg); ?></span>
    </form>
    <h2 style="margin-top:40px;">Blog Preview & PDF Download</h2>
    <div id="blogPreview" style="opacity:<?php echo ($blogPublic=="public"?"1":"0.5"); ?>">
      <?php
      $company = getCompany();
      $user = getUser();
      $weeks = getEntries();
      $images = getImages();
      if ($company && !empty($company['companyName'])) {
        echo '<div class="blog-entry"><strong>Internship Details</strong><ul>';
        echo '<li><b>Company:</b> '.htmlspecialchars($company['companyName']).'</li>';
        echo '<li><b>Location:</b> '.htmlspecialchars($company['companyLocation']).'</li>';
        echo '<li><b>Website:</b> <a href="'.htmlspecialchars($company['companyWebsite']).'" target="_blank">'.htmlspecialchars($company['companyWebsite']).'</a></li>';
        echo '<li><b>Mentor:</b> '.htmlspecialchars($company['companyMentor']).'</li>';
        echo '<li><b>Role:</b> '.htmlspecialchars($company['internRole']).'</li>';
        echo '<li><b>Period:</b> '.htmlspecialchars($company['internPeriod']).'</li>';
        echo '<li><b>User:</b> '.htmlspecialchars($user).'</li></ul></div>';
      }
      foreach ($weeks as $week) {
        echo '<div class="blog-entry">';
        echo '<h3>Week '.htmlspecialchars($week['week']).'</h3>';
        echo '<table border="1" cellpadding="4" style="width:100%;max-width:900px">';
        echo '<tr><th>Day</th><th>Date</th><th>Reflection</th><th>Achievements</th><th>Learning</th></tr>';
        // Feedback columns removed below!
        if (isset($week['days']) && is_array($week['days'])) {
          foreach ($week['days'] as $d => $entry) {
            echo '<tr>';
            echo '<td>'.(isset($entry['day']) ? htmlspecialchars($entry['day']) : ($d+1)).'</td>';
            echo '<td>'.htmlspecialchars($entry['date']).'</td>';
            echo '<td>'.htmlspecialchars($entry['reflection']).'</td>';
            echo '<td>'.htmlspecialchars($entry['achievements']).'</td>';
            echo '<td>'.htmlspecialchars($entry['learning']).'</td>';
            echo '</tr>';
          }
        }
        echo '</table>';
        echo '</div>';
      }
      // Uploaded Images after all days
      echo '<div class="blog-entry" style="margin-top:30px;">';
      echo '<h3>Uploaded Images</h3>';
      if (!empty($images)) {
        echo '<div style="display:flex;flex-wrap:wrap;gap:10px;">';
        foreach ($images as $img) {
          echo '<img src="'.htmlspecialchars($img).'" alt="Uploaded Image" style="max-width:180px;max-height:180px;border:1px solid #ccc;padding:3px;background:#f9f9f9;">';
        }
        echo '</div>';
      } else {
        echo '<p>No images uploaded yet.</p>';
      }
      echo '</div>';

      $includedFeedbacks = getMentorFeedbacks();
      if (count($includedFeedbacks) > 0) {
        echo '<h3>Mentor Feedback Included in Report</h3>';
        foreach ($includedFeedbacks as $fb) {
          echo '<div class="blog-entry">
            <strong>'.htmlspecialchars($fb['mentorName']).'</strong> ('.htmlspecialchars($fb['feedbackDate']).')<br/>
            <em>'.htmlspecialchars($fb['mentorFeedback']).'</em>
          </div>';
        }
      }
      ?>
    </div>
    <!-- The rest of your code is unchanged... -->
    <button id="generatePDF">Download PDF</button>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script>
      document.getElementById("generatePDF").onclick = function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        doc.setFontSize(24);
        doc.text("Internship Blog", 20, 20);
        let y = 35;
        <?php
        $company = getCompany();
        $user = getUser();
        ?>
        doc.setFontSize(16);
        doc.text("Internship Details", 20, y); y += 8;
        doc.setFontSize(12);
        doc.text("Company: <?php echo addslashes($company['companyName']); ?>", 22, y); y += 7;
        doc.text("Location: <?php echo addslashes($company['companyLocation']); ?>", 22, y); y += 7;
        doc.text("Website: <?php echo addslashes($company['companyWebsite']); ?>", 22, y); y += 7;
        doc.text("Mentor: <?php echo addslashes($company['companyMentor']); ?>", 22, y); y += 7;
        doc.text("Role: <?php echo addslashes($company['internRole']); ?>", 22, y); y += 7;
        doc.text("Period: <?php echo addslashes($company['internPeriod']); ?>", 22, y); y += 7;
        doc.text("User: <?php echo addslashes($user); ?>", 22, y); y += 7;
        y += 6;
        // Entries
        <?php
        foreach ($weeks as $week) {
          if (isset($week['days']) && is_array($week['days'])) {
            foreach ($week['days'] as $entry) {
        ?>
        doc.setFontSize(14);
        doc.text("Week <?php echo addslashes($week['week']); ?> - Day <?php echo addslashes($entry['day'] ?? ''); ?> (<?php echo addslashes($entry['date']); ?>)", 20, y); y += 8;
        doc.setFontSize(12);
        <?php if (!empty($entry['reflection'])) { ?>
        doc.text("Reflection: <?php echo addslashes($entry['reflection']); ?>", 22, y); y += 7;
        <?php } ?>
        <?php if (!empty($entry['achievements'])) { ?>
        doc.text("Achievements: <?php echo addslashes($entry['achievements']); ?>", 22, y); y += 7;
        <?php } ?>
        <?php if (!empty($entry['learning'])) { ?>
        doc.text("Learning Outcomes: <?php echo addslashes($entry['learning']); ?>", 22, y); y += 7;
        <?php } ?>
        y += 4;
        if (y > 260) { doc.addPage(); y = 20; }
        <?php }}} ?>
        // Uploaded Images
        <?php if (!empty($images)) { ?>
        doc.addPage();
        y = 20;
        doc.setFontSize(16);
        doc.text("Uploaded Images", 20, y); y += 10;
        <?php foreach ($images as $img) { ?>
        // Image embedding requires base64 and must be loaded client-side, not here
        // doc.addImage('<?php echo addslashes($img); ?>', "JPEG", 22, y, 40, 40); y += 44;
        <?php } ?>
        <?php } ?>
        // Mentor feedbacks if included
        <?php
        if (count($includedFeedbacks) > 0) {
        ?>
        doc.addPage();
        y = 20;
        doc.setFontSize(16);
        doc.text("Mentor Feedback Included in Report", 20, y);
        y += 8;
        doc.setFontSize(12);
        <?php foreach ($includedFeedbacks as $fb) { ?>
        doc.text("<?php echo addslashes($fb['mentorName']); ?> (<?php echo addslashes($fb['feedbackDate']); ?>):", 22, y); y += 7;
        doc.text("<?php echo addslashes($fb['mentorFeedback']); ?>", 24, y); y += 12;
        if (y > 260) { doc.addPage(); y = 20; }
        <?php } ?>
        <?php } ?>
        doc.save("InternshipBlog.pdf");
      };
    </script>
    <h2 style="margin-top:40px;">Share Your Portfolio</h2>
    <input id="portfolioUrl" readonly value="<?php echo htmlspecialchars($portfolioUrl); ?>" />
    <button id="sharePortfolio" type="button">Copy Link</button>
    <span id="copiedMsg"></span>
    <p>Share this link with mentors or employers!</p>
    <script>
      document.getElementById("sharePortfolio").onclick = function() {
        const input = document.getElementById("portfolioUrl");
        input.select();
        document.execCommand("copy");
        document.getElementById("copiedMsg").textContent = "Copied!";
        setTimeout(() => document.getElementById("copiedMsg").textContent = "", 1800);
      };
    </script>
  </main>
</body>
</html>