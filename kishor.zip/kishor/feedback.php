<?php
session_start();
$feedbackMsg = "";
if (!isset($_SESSION['feedbacks'])) {
    $_SESSION['feedbacks'] = [];
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mentorName = $_POST["mentorName"] ?? "";
    $feedbackDate = $_POST["feedbackDate"] ?? "";
    $mentorFeedback = $_POST["mentorFeedback"] ?? "";
    $includeInReport = isset($_POST["includeInReport"]) ? "Yes" : "No";

    if ($mentorName && $feedbackDate && $mentorFeedback) {
        $entry = [
            'mentorName' => $mentorName,
            'feedbackDate' => $feedbackDate,
            'mentorFeedback' => $mentorFeedback,
            'includeInReport' => $includeInReport
        ];
        $_SESSION['feedbacks'][] = $entry;
        $feedbackMsg = "Feedback saved successfully!";
    } else {
        $feedbackMsg = "All fields are required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Mentor Feedback Management</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="index.php">Login</a>
    <a href="company.php">Company Details</a>
    <a href="reflection.php">Log Reflection</a>
    <a href="feedback.php" class="active">Mentor Feedback</a>
    <a href="upload.php">Upload Images</a>
    <a href="ai.php">AI Writing</a>
    <a href="style.php">Blog Style</a>
  </nav>
  <main>
    <h2>Mentor Feedback Management</h2>
    <form id="feedbackForm" method="post" action="">
      <label for="mentorName">Mentor Name:</label>
      <input type="text" id="mentorName" name="mentorName" required />

      <label for="feedbackDate">Date of Feedback:</label>
      <input type="date" id="feedbackDate" name="feedbackDate" required />

      <label for="mentorFeedback">Mentor Feedback:</label>
      <textarea id="mentorFeedback" name="mentorFeedback" required placeholder="Paste or summarize feedback received from mentor"></textarea>

      <label>
        <input type="checkbox" id="includeInReport" name="includeInReport" checked />
        Include this feedback in the final report
      </label>

      <button type="submit">Save Feedback</button>
    </form>
    <div id="feedbackMsg"><?php echo htmlspecialchars($feedbackMsg); ?></div>
    <div id="feedbackList">
      <?php
      if (!empty($_SESSION['feedbacks'])) {
        echo "<h3>Saved Feedbacks:</h3><ul>";
        foreach ($_SESSION['feedbacks'] as $f) {
          echo "<li><strong>Mentor:</strong> " . htmlspecialchars($f['mentorName']) .
               " <strong>Date:</strong> " . htmlspecialchars($f['feedbackDate']) .
               " <br><strong>Feedback:</strong> " . nl2br(htmlspecialchars($f['mentorFeedback'])) .
               " <br><strong>Include in Report:</strong> " . htmlspecialchars($f['includeInReport']) .
               "</li><hr>";
        }
        echo "</ul>";
      }
      ?>
    </div>
  </main>
</body>
</html>