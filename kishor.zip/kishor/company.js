document.getElementById('companyForm').onsubmit = function(e) {
  e.preventDefault();
  const details = {
    name: document.getElementById('companyName').value,
    location: document.getElementById('companyLocation').value,
    website: document.getElementById('companyWebsite').value,
    mentor: document.getElementById('companyMentor').value,
    role: document.getElementById('internRole').value,
    period: document.getElementById('internPeriod').value
  };
  localStorage.setItem('intern_company', JSON.stringify(details));
  document.getElementById('companyMsg').textContent = "Company details saved!";
  setTimeout(() => document.getElementById('companyMsg').textContent = "", 2000);
  this.reset();
};