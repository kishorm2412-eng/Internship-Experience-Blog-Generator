<?php
session_start();

$loginMsg = "";

// Enforce required credentials
$required_username = "harini@gmail.com";
$required_password = "harini";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"] ?? "";
    $password = $_POST["password"] ?? "";

    if ($username === $required_username && $password === $required_password) {
        $_SESSION["blog_user"] = "Harini";
        $_SESSION["logged_in"] = true;
        // Redirect to company page after login
        header("Location: company.php");
        exit();
    } else {
        $loginMsg = "Invalid credentials. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Internship Blog Generator - Login</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="login.php" class="active">Login</a>
    <a href="company.php">Company Details</a>
    <a href="reflection.php">Log Reflection</a>
    <a href="feedback.php">Mentor Feedback</a>
    <a href="upload.php">Upload Images</a>
    <a href="ai.php">AI Writing</a>
    <a href="style.php">Blog Style</a>
  </nav>
  <main>
    <h1>Login to Internship Blog Generator</h1>
    <form id="loginForm" method="post" action="">
      <label for="username">Email:</label>
      <input type="text" id="username" name="username" required autocomplete="username" />

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required autocomplete="current-password" />

      <button type="submit">Login</button>
    </form>
    <div id="loginMsg" style="color:#b00;margin-top:10px;"><?php echo htmlspecialchars($loginMsg); ?></div>
    <div style="margin-top:18px;color:#888;">
    </div>
  </main>
</body>
</html>