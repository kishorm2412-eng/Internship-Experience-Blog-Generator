document.getElementById("blogStyle").value = getStyle();
document.getElementById("blogPublic").value = getPublic() ? "public" : "private";
document.getElementById("blogStyle").onchange = function() {
  setStyle(this.value);
  document.getElementById("styleMsg").textContent = "Style saved!";
  setTimeout(() => document.getElementById("styleMsg").textContent = "", 1500);
};
document.getElementById("blogPublic").onchange = function() {
  setPublic(this.value === "public");
  document.getElementById("styleMsg").textContent = "Privacy setting saved!";
  setTimeout(() => document.getElementById("styleMsg").textContent = "", 1500);
};