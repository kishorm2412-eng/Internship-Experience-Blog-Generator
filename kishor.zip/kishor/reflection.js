document.getElementById("reflectionForm").onsubmit = function(e) {
  e.preventDefault();
  const week = document.getElementById("week").value;
  const date = document.getElementById("date").value;
  const reflection = document.getElementById("reflection").value;
  const achievements = document.getElementById("achievements").value;
  const learning = document.getElementById("learning").value;
  let entries = getEntries();
  entries.push({
    week,
    date,
    reflection,
    achievements,
    learning,
    feedback: "", // For compatibility with previous data
    photoUrl: ""
  });
  saveEntries(entries);
  document.getElementById("reflectionMsg").textContent = "Entry saved!";
  setTimeout(() => document.getElementById("reflectionMsg").textContent = "", 2000);
  this.reset();
};