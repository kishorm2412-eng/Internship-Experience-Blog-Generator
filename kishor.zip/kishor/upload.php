<?php
session_start();
$uploadMsg = "";

// Create directory for uploads if not exists
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Handle image upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['photo'])) {
    $file = $_FILES['photo'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB

    if ($file['error'] === UPLOAD_ERR_OK) {
        if (in_array($file['type'], $allowedTypes) && $file['size'] <= $maxSize) {
            $filename = uniqid("img_") . "_" . basename($file['name']);
            $targetPath = $uploadDir . $filename;
            if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                // Store uploaded image path in session
                $_SESSION['uploaded_images'][] = $targetPath;
                $uploadMsg = "Image uploaded successfully!";
            } else {
                $uploadMsg = "Failed to move uploaded file.";
            }
        } else {
            $uploadMsg = "Invalid file type or size exceeds 5MB.";
        }
    } else {
        $uploadMsg = "File upload error.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Upload Images</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  <nav>
    <a href="index.php">Login</a>
    <a href="company.php">Company Details</a>
    <a href="reflection.php">Log Reflection</a>
    <a href="feedback.php">Mentor Feedback</a>
    <a href="upload.php" class="active">Upload Images</a>
    <a href="ai.php">AI Writing</a>
    <a href="style.php">Blog Style</a>
  </nav>
  <main>
    <h2>Upload Images</h2>
    <form id="imageForm" method="post" enctype="multipart/form-data" action="">
      <label>Select Image:</label>
      <input type="file" id="photo" name="photo" accept="image/*" required />
      <button type="submit">Upload</button>
    </form>
    <div id="imagesPreview">
      <?php
      if (!empty($uploadMsg)) {
        echo "<p>" . htmlspecialchars($uploadMsg) . "</p>";
      }
      if (!empty($_SESSION['uploaded_images'])) {
        echo "<h3>Uploaded Images:</h3>";
        foreach ($_SESSION['uploaded_images'] as $img) {
          echo '<div style="display:inline-block;margin:10px;"><img src="' . htmlspecialchars($img) . '" style="max-width:200px;max-height:200px;" /></div>';
        }
      }
      ?>
    </div>
  </main>
</body>
</html>